sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("ch.novobc.novoinnoappmodule.controller.App", {
        onInit: function() {
          
        }
      });
    }
  );
  